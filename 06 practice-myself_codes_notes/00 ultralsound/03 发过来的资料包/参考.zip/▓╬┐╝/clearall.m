clear all
rmdir('rf_data','s');

