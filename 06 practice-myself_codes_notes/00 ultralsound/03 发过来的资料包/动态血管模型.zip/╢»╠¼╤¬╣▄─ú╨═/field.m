%  Start up the Field II simulation system
%
%  Version 1.1, August 13, 2007, JAJ

%  Replace the second path with the name of the directory
%  for your Field II m-files and executable

path(path, 'D:\��һ��ѧ�ڿμ�\ҽѧ����\Field_II_PC7')

field_init
