How to run:
1. Set the path properly*.
2. Run the MainRunProgram.m script.

* You have to download the NSCT toolbox and set its' path properly in MainRunProgram.m. You might have to compile the C/C++ files of NSCT toolbox using MATLAB 'mex' command.
